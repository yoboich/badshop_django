from django.forms import ModelForm, forms, widgets

from items.models import Item, CertificateImages


# class AddItemForm(ModelForm):
#     class Meta:
#         model = Item
#         fields = '__all__'

